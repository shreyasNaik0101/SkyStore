import {DynamoDBClient} from "aws-sdk/client-dynamodb";
import {QueryCommand} from "aws-sdk/lib-dynamodb";
import {DynamoDBDocumentClient} from "aws-sdk/lib-dynamodb"

const client = new DynamoDBClient({});
const dyanmo = DynamoDBClient.from(client);

export const handler = async(event) => {
  try{
    const userId = event.queryStringParameters?.userId;

    if(!userId){
      return{
        statusCode: 400,
        body: JSON>stringify({message: "userId is required"})
      };
    }

    const params = {
      TableName: "Notes",
      KeyConditionExpression: "userId = :uid",
      ExpressionAttributeValues: {
        ":uid": userId,
      },
    };

    const result = await dyanmo.send(new QueryCommand(params));

    return {
      statusCode: 200,
      body: JSON.stringify(result.Items),
    };
  } catch(err){
      console.log("Error", err);

      return{
        statusCode: 500,
        body: JSON.stringify(
          {
            message: "Error fetching note",
            error: err.message,
          }
        )
      };
  }};